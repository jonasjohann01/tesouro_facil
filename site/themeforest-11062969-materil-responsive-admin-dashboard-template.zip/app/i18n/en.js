{

"header" : {
  "navbar" : {
    "DASHBOARD" : "Dashboard",
    "EMAIL" : "Email",
    "UIKITS" : "UI Kits",
    "PAGES" : "Pages"
  }
}

}
